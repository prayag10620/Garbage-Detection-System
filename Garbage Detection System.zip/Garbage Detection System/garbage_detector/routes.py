from flask import Flask, render_template, request, flash, redirect, url_for
import urllib.request
import os
from garbage_detector import app
#from werkzeug.utils import secure_filename
from garbage_detector.forms import DetailsForm
from PIL import Image,ImageFont
from geopy.geocoders import Nominatim
import folium
from datetime import datetime
from flask_mongoengine import MongoEngine
import cv2
import numpy as np
from flask_mail import Mail, Message


mail = Mail(app)

#from mongoengine import connect, fields, Document
#import gridfs

geolocator = Nominatim(user_agent="http")


#initialize database
db = MongoEngine()
db.init_app(app)
#connect(db="GarbageDetector", host="localhost", port=27017)

class User(db.Document):
    # meta = {"collection": "my_users"}

    complaint_no = db.SequenceField(primary_key=True)
    date = db.DateTimeField(default=datetime.utcnow())
    email = db.StringField()
    city = db.StringField()
    place = db.StringField()
    zip_code = db.StringField()
    imagefile = db.StringField()
    lat = db.StringField()
    log = db.StringField()
    #garbage_pic = db.FileField(thumbnail_size=(150,150, False))
    garbage_pic = db.ImageField(thumbnail_size=(150, 150, False))


@app.route("/")
def home():
    return render_template("index.html")


def save_pic(img,filename):
    # _, f_ext = os.path.splitext(form_picture.filename)
    # filename = form_picture.filename
    #form_picture.save(filename
    picture_path = os.path.join(app.root_path, 'static/imgs', filename)

    

    # img = Image.open(form_picture)

    return filename , picture_path

def predict(form_picture):
    net = cv2.dnn.readNet("C:/Users/Lenovo/Desktop/demoproject/Garbage_Detection_new/garbage_detector/yolov3_last_project.weights","C:/Users/Lenovo/Desktop/demoproject/Garbage_Detection_new/garbage_detector/yolov3_last.cfg")
    

    # Name custom object
    classes = ["can", "polythene", "wrapper", "bottle", "trash"]

    # Images path
    layer_names = net.getLayerNames()
    output_layers = [layer_names[i[0] - 1] for i in net.getUnconnectedOutLayers()]
    colors = np.random.uniform(0, 255, size=(len(classes), 3))
    #   img = cv2.imread(image_path)

    _, f_ext = os.path.splitext(form_picture.filename)
    filename = form_picture.filename
    #form_picture.save(filename)
    picture_path = os.path.join(app.root_path, 'static\imgs', filename)
    img = Image.open(form_picture)
    img = np.array(img, dtype=np.float32)
    #img = np.expand_dims(img, axis=0)

    height, width, channels = img.shape
    # Detecting objects
    blob = cv2.dnn.blobFromImage(img, 0.00392, (416, 416), (0, 0, 0), True, crop=False)

    net.setInput(blob)
    outs = net.forward(output_layers)

    class_ids = []
    confidences = []
    boxes = []
    for out in outs:
        for detection in out:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > 0.3:
                # Object detected
                # print(class_id)
                center_x = int(detection[0] * width)
                center_y = int(detection[1] * height)
                w = int(detection[2] * width)
                h = int(detection[3] * height)

                # Rectangle coordinates
                x = int(center_x - w / 2)
                y = int(center_y - h / 2)

                boxes.append([x, y, w, h])
                confidences.append(float(confidence))
                class_ids.append(class_id)

    indexes = cv2.dnn.NMSBoxes(boxes, confidences, 0.5, 0.4)
    # print(indexes)
    font = cv2.FONT_HERSHEY_TRIPLEX

    for i in range(len(boxes)):
        if i in indexes:
            x, y, w, h = boxes[i]
            label = str(classes[class_ids[i]])
            color = colors[class_ids[i]]
            text = "{}: {:.4f}".format(classes[class_ids[i]], confidences[i]*100)
            cv2.rectangle(img, (x, y), (x + w, y + h), color, 2)
            cv2.putText(img, text, (x, y + 30), font, 1, color, 2)

    if len(class_ids)!=0:
        cv2.imwrite(picture_path , img)
        garbage = 1  
        return img , garbage , filename

    else:
        garbage = 0
        return img , garbage , None
    

@app.route("/details", methods=['GET', 'POST'])
def Details():
    form = DetailsForm()
    if form.validate_on_submit():
        if form.picture.data:
            res_img , garbage, fname = predict(form.picture.data)
            # imgfile , img = load_pic(form.picture.data)
        
        user_email = form.email.data
        user_place = form.place.data
        user_city = form.city.data
        user_zip = form.zipcode.data
        user_pic = form.picture.data
        img_file = form.picture.data.filename

        #adjusting the address details in same case.
        user_place = user_place.lower()
        user_city = user_city.lower()
            
        
        if garbage == 1:

            try:
                address = user_place + ", "+ user_city + ", " + user_zip
                location = geolocator.geocode(address) 
            except:
                address = user_city + " " + user_zip
                location = geolocator.geocode(address)
            
            lt = location.latitude
            longi = location.longitude
            #save the deatils to MongoDBdatabase
            # gimg = Image.open(res_img)
            print(fname)
            gdetails = User(date=datetime.now(), email=user_email, city=user_city, zip_code=user_zip, place=user_place, imagefile=img_file,lat = str(lt),log=str(longi))
            #gdetails.garbage_pic.replace(gimg, filename=imgfile)
            gdetails.save()

            #if want to retrieve image
            #myuser = User.objects(email=gdetails.email).first()
            #im = Image.open(myuser.garbage_pic.read())

            
            #filename = secure_filename(user_pic)
            #user_pic.save(path)
            # print(user_email, address, imgfile)
            # print(lt, longi)

            #creating map
            start_coords = [lt, longi]
            folium_map = folium.Map(location = start_coords, zoom_start=14)
            tooltip = user_city
            folium.Marker(start_coords, tooltip=tooltip).add_to(folium_map)
            map_path = os.path.join(app.root_path, 'templates', 'map.html')
            folium_map.save(map_path)

            # with open('C:/Users/Lenovo/Desktop/demoproject/Garbage_Detection_new/garbage_detector/templates/mail.html', 'r') as f:
            #     src = f.read()
            
            # env = Environment(loader=FileSystemLoader('C:/Users/Lenovo/Desktop/demoproject/Garbage_Detection_new/garbage_detector/templates/mail.html'))
            # htmlstr = env.render(body)

            with app.app_context():
                subject = "Complaint registration for Garbage cleaning"
                msg = Message(subject, sender="infofeedtechnology@gmail.com", recipients = [user_email])
                body = "Hello \n Your Complaint has been registered successfully regarding the garbage detection near {} in {} zone. \n The complaint number is 1111. we assure you the garbage will be cleaned within a day".format(user_place, user_zip)
                # msg.html = 
                
                # "Hello \n Your Complaint has been registered successfully regarding the garbage detection near {} in {} zone. \n The complaint number is 1111. we assure you the garbage will be cleaned within a day".format(user_place, user_zip)
                msg.body = body
                mail.send(msg)
            
                print("mail-sent")

            return render_template('results.html', garbage = garbage , myemail=user_email, mycity=user_city, picture_path = fname)

        else:
            return render_template('results.html',garbage=garbage , myemail=user_email, mycity=user_city)

    return render_template('details.html', form = form)


@app.route("/results") 
def results():
    return render_template("results.html")
