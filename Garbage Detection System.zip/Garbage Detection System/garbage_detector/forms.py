from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired, Email, ValidationError

class DetailsForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    city = StringField('City', validators=[DataRequired()])
    place = StringField('Place', validators=[DataRequired()])
    zipcode = StringField('Zip Code', validators=[DataRequired()])
    picture = FileField('Upload garbage Picture', validators=[DataRequired(), FileAllowed(['jpg','jpeg' ,'png'])])

    submit = SubmitField('Submit')

