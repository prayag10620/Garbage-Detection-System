from flask import Flask
#from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_mail import Mail, Message
import smtplib


app = Flask(__name__)

upload_location = "C:/Users/admin/garbage_detector/static"

local_server = True
app.secret_key = "its_secret"
app.config['UPLOAD_FOLDER'] = upload_location
app.config['MAX_CONTENT_LENGTH'] = 16*1024*1024
#app.config['GOOGLEMAPS_KEY'] = "AIzaSyCjQ5pIURJKgJZx9RjT3mOIgAYNHgdwq_g"
#MongoDB connection
app.config['MONGODB_SETTINGS'] = {
    'db': 'GarbageDetector',
    'host': 'localhost',
    'port': 27017
}
app.config['EMAIL_BACKEND']  = "emails.backend.SMTPBackend"
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'infofeedtechnology@gmail.com'
app.config['MAIL_PASSWORD'] = 'Srsp@16200'
app.config['MAIL_USE_SSL'] = True
app.config['MAIL_USE_TLS'] = False

from garbage_detector import routes
